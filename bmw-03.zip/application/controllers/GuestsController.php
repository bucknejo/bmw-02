<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of GuestsController
 *
 * @author jb197342
 */
class GuestsController {
    //put your code here
}

?>
