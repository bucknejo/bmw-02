if(!window.console) {window.console = {log: function(){}}}
